using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

[System.ComponentModel.Description("AJAXSampleProvider")]
public partial class AJAXSampleProvider : System.Web.UI.UserControl, SmartPart.IConnectionProviderControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    #region IConnectionProviderControl Members

    public object GetProviderData()
    {
        return new SmartPart.AJAXConnectionData(
            TextBox1.Text, Button1, "Click");
    }

    public string ProviderMenuLabel
    {
        get { return "Sends text data to"; }
    }

    #endregion
}
