using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

[System.ComponentModel.Description("AJAXSampleConsumer")]
public partial class AJAXSampleConsumer : System.Web.UI.UserControl, SmartPart.IConnectionConsumerControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    #region IConnectionConsumerControl Members

    public string ConsumerMenuLabel
    {
        get { return "Receives text data from"; }
    }

    public void SetConsumerData(object data)
    {
        if(data != null)
            if(data.GetType() == typeof(SmartPart.AJAXConnectionData))
            {
                SmartPart.AJAXConnectionData ajaxData = (SmartPart.AJAXConnectionData)data;

                ajaxData.RegisterTriggerControls(this.UpdatePanel1);
                TextBox1.Text = ajaxData.Data.ToString();
            }
    }

    #endregion
}
